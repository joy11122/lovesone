import { describe, expect, it } from "vitest";
import { formatBDT, toMinorUnits } from "@/lib/money";

describe("money helpers", () => {
  it("converts BDT to minor units without floating point drift", () => {
    expect(toMinorUnits(12.34)).toBe(1234);
  });
  it("rejects negative or non-finite amounts", () => {
    expect(() => toMinorUnits(-1)).toThrow();
    expect(() => toMinorUnits(Number.NaN)).toThrow();
  });
  it("formats BDT values", () => {
    expect(formatBDT(250)).toContain("250");
  });
});
