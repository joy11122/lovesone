import { expect, test } from "@playwright/test";

test("home page exposes core marketplace navigation", async ({ page }) => {
  await page.goto("/");
  await expect(page).toHaveTitle(/LOVESONE/);
  await expect(page.getByRole("heading", { name: /Big love for/i })).toBeVisible();
  await expect(page.getByRole("link", { name: /Shop the goodies/i })).toBeVisible();
  await expect(page.getByRole("link", { name: /Start selling/i })).toBeVisible();
});
