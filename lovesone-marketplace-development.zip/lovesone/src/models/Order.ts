import { Schema, model, models } from "mongoose";

const orderLineSchema = new Schema({
  productId: { type: Schema.Types.ObjectId, ref: "Product", required: true },
  titleSnapshot: { type: String, required: true },
  quantity: { type: Number, required: true, min: 1 },
  unitPrice: { type: Number, required: true, min: 0 }
}, { _id: false });

const subOrderSchema = new Schema({
  vendorId: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
  items: { type: [orderLineSchema], required: true },
  subtotal: { type: Number, required: true, min: 0 },
  commissionAmount: { type: Number, required: true, min: 0 },
  vendorNetAmount: { type: Number, required: true, min: 0 },
  status: { type: String, enum: ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"], default: "pending" }
}, { timestamps: true });

const orderSchema = new Schema({
  orderNumber: { type: String, required: true, unique: true },
  customerId: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
  subOrders: { type: [subOrderSchema], required: true },
  total: { type: Number, required: true, min: 0 },
  paymentMethod: { type: String, enum: ["cod", "sslcommerz", "bkash", "nagad"], required: true },
  paymentStatus: { type: String, enum: ["pending", "authorized", "paid", "failed", "refunded"], default: "pending" },
  status: { type: String, enum: ["pending", "processing", "partially-shipped", "shipped", "delivered", "cancelled"], default: "pending" },
  shippingAddress: { recipient: String, phone: String, email: String, addressLine: String, district: String, area: String },
  gatewayData: { sessionId: String, transactionId: String, paymentReferenceId: String, redirectUrl: String, initiatedAt: Date, verifiedAt: Date, failureReason: { type: String, maxlength: 300 } },
  returnRequest: { status: { type: String, enum: ["none", "requested", "approved", "rejected", "refunded"], default: "none" }, reason: { type: String, maxlength: 1000 }, requestedAt: Date, reviewedAt: Date, adminNote: String },
  idempotencyKey: { type: String, required: true, unique: true }
}, { timestamps: true });
orderSchema.index({ customerId: 1, createdAt: -1 });
export const Order = models.Order || model("Order", orderSchema);
