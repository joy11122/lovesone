import { Schema, model, models } from "mongoose";

const userSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, select: false },
  role: { type: String, enum: ["customer", "vendor", "support", "admin", "super-admin"], default: "customer", index: true },
  status: { type: String, enum: ["active", "suspended", "pending"], default: "active" },
  emailVerifiedAt: Date
}, { timestamps: true });
export const User = models.User || model("User", userSchema);
