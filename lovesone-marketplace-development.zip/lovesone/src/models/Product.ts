import { Schema, model, models, type InferSchemaType } from "mongoose";

const productSchema = new Schema({
  vendorId: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 120 },
  slug: { type: String, required: true, trim: true, lowercase: true },
  description: { type: String, required: true, maxlength: 5000 },
  petTypes: [{ type: String, enum: ["cat", "dog", "bird", "fish", "rabbit", "small-pet"] }],
  categorySlug: { type: String, required: true, index: true },
  price: { type: Number, required: true, min: 0 },
  compareAtPrice: { type: Number, min: 0 },
  sku: { type: String, required: true, trim: true },
  stock: { type: Number, required: true, min: 0, default: 0 },
  images: [{ type: String }],
  status: { type: String, enum: ["draft", "pending-review", "active", "rejected", "archived"], default: "pending-review", index: true },
  medicine: { isMedicine: { type: Boolean, default: false }, requiresPrescription: { type: Boolean, default: false }, approvalReference: String },
  deletedAt: { type: Date, default: null }
}, { timestamps: true });
productSchema.index({ vendorId: 1, sku: 1 }, { unique: true });
productSchema.index({ title: "text", description: "text" });
export type ProductDocument = InferSchemaType<typeof productSchema>;
export const Product = models.Product || model("Product", productSchema);
