import { Schema, model, models } from "mongoose";

const vendorProfileSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: "User", required: true, unique: true },
  storeName: { type: String, required: true, trim: true, maxlength: 100 },
  slug: { type: String, required: true, unique: true, lowercase: true },
  description: { type: String, maxlength: 2000 },
  phone: { type: String, required: true },
  businessAddress: { type: String, required: true },
  verificationStatus: { type: String, enum: ["pending", "under-review", "verified", "rejected", "suspended"], default: "pending", index: true },
  commissionRate: { type: Number, min: 0, max: 100, default: 10 },
  payoutDetails: { type: Schema.Types.Mixed, select: false }
}, { timestamps: true });
export const VendorProfile = models.VendorProfile || model("VendorProfile", vendorProfileSchema);
