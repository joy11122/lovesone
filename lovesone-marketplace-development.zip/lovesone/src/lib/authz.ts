import "server-only";
import { redirect } from "next/navigation";
import { auth } from "../../auth";

export type AppRole = "customer" | "vendor" | "support" | "admin" | "super-admin";

export async function requireUser() {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");
  return session.user;
}

export async function requireRole(allowed: AppRole[]) {
  const user = await requireUser();
  if (!allowed.includes(user.role as AppRole)) redirect("/");
  return user;
}
