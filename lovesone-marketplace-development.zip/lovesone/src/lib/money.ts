export function toMinorUnits(amount: number) {
  if (!Number.isFinite(amount) || amount < 0) throw new Error("Invalid monetary amount");
  return Math.round(amount * 100);
}
export function formatBDT(amount: number) {
  return new Intl.NumberFormat("en-BD", { style: "currency", currency: "BDT", maximumFractionDigits: 2 }).format(amount);
}
