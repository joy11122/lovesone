export type Category = {
  name: string;
  description: string;
  emoji: string;
  tone: string;
  slug: string;
};

export const categories: Category[] = [
  { name: "Food & treats", description: "Tasty everyday nutrition", emoji: "🥣", tone: "#ffe1c9", slug: "food" },
  { name: "Toys & play", description: "More fun, less boredom", emoji: "🧸", tone: "#e8ddff", slug: "toys" },
  { name: "Health & care", description: "Care essentials", emoji: "🩺", tone: "#d8f1df", slug: "health" },
  { name: "Fashion", description: "Little looks, big personality", emoji: "🧢", tone: "#fff0b8", slug: "fashion" },
  { name: "Beds & home", description: "Comfy corners for them", emoji: "🛏️", tone: "#dcecff", slug: "home" },
  { name: "Grooming", description: "Fresh, fluffy and clean", emoji: "🫧", tone: "#f9ddeb", slug: "grooming" }
];

export type Product = {
  id: string;
  name: string;
  pet: string;
  price: number;
  rating: number;
  emoji: string;
  tone: string;
  label?: string;
};

export const featuredProducts: Product[] = [
  { id: "purr-bites", name: "Purr Bites Ocean Blend", pet: "Cats · Food", price: 650, rating: 4.9, emoji: "🐟", tone: "#dcecff", label: "Bestseller" },
  { id: "happy-paws", name: "Happy Paws Chew Toy", pet: "Dogs · Toys", price: 320, rating: 4.8, emoji: "🦴", tone: "#ffe3cb", label: "Popular" },
  { id: "cozy-nest", name: "Cozy Nest Pet Bed", pet: "Cats & dogs · Home", price: 1450, rating: 4.9, emoji: "🛏️", tone: "#e7defd" },
  { id: "birdie-mix", name: "Birdie Daily Seed Mix", pet: "Birds · Food", price: 280, rating: 4.7, emoji: "🦜", tone: "#dff2df" }
];