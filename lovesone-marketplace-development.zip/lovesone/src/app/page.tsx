import Link from "next/link";
import { ArrowRight, Heart, PawPrint, ShieldCheck, Truck } from "lucide-react";
import { categories, featuredProducts } from "@/lib/catalog";

export default function HomePage() {
  return (
    <>
      <section className="overflow-hidden py-12 sm:py-16">
        <div className="container grid items-center gap-8 lg:grid-cols-[1.05fr_.95fr]">
          <div className="relative z-10">
            <span className="eyebrow"><PawPrint size={14}/> For every kind of pet person</span>
            <h1 className="mt-5 max-w-[650px] text-[clamp(42px,7vw,76px)] font-black leading-[.99] tracking-[-.065em]">
              Big love for <span className="text-[#ff914d]">little</span> (and not-so-little) paws.
            </h1>
            <p className="mt-5 max-w-lg text-lg leading-8 text-[#777487]">Food, toys, care and all the happy little things your best friend deserves. Meet your new favorite pet shop.</p>
            <div className="mt-7 flex flex-wrap gap-3"><Link className="btn" href="/shop">Shop the goodies <ArrowRight size={17}/></Link><Link className="btn secondary" href="/vendor/register">Become a seller</Link></div>
            <div className="mt-8 flex flex-wrap gap-5 text-xs font-bold text-[#777487]"><span className="flex items-center gap-2"><Truck size={16}/> Delivery across Bangladesh</span><span className="flex items-center gap-2"><ShieldCheck size={16}/> Seller-reviewed listings</span></div>
          </div>
          <div className="relative mx-auto w-full max-w-[550px]">
            <div className="absolute -inset-5 rotate-3 rounded-[48px] bg-[#ffd166]"/>
            <div className="relative grid min-h-[390px] place-items-center overflow-hidden rounded-[42px] bg-[#e9defe] sm:min-h-[470px]">
              <div className="absolute left-8 top-8 rounded-full bg-white px-4 py-2 text-sm font-extrabold shadow-sm">Hello, bestie! 💛</div>
              <div className="text-center">
                <div className="text-[150px] leading-none sm:text-[190px]">🐶</div>
                <div className="-mt-3 text-[72px] sm:text-[90px]">🐱</div>
              </div>
              <div className="absolute bottom-7 right-6 rotate-6 rounded-2xl bg-white px-4 py-3 text-sm font-extrabold shadow-lg">Made for happy tails ✨</div>
              <div className="absolute bottom-8 left-7 text-4xl">🧶</div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-[#f0e9e1] bg-white/60 py-5">
        <div className="container grid grid-cols-2 gap-4 text-center sm:grid-cols-4">
          {[["🐾","For every pet"],["💛","Seller-loved finds"],["📦","Easy order tracking"],["🤝","A growing pet community"]].map(([emoji,label]) => <div key={label} className="text-sm font-bold"><span className="mr-2 text-lg">{emoji}</span>{label}</div>)}
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-heading"><div><span className="eyebrow">Find their favorites</span><h2>Shop by category</h2><p>Little essentials for every big personality.</p></div><Link className="text-sm font-extrabold text-[#d96f32]" href="/shop">Explore all <ArrowRight className="ml-1 inline" size={16}/></Link></div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {categories.map((category) => <Link href={`/shop?category=${category.slug}`} key={category.slug} className="category-card p-3 text-center sm:p-4"><div className="category-art rounded-2xl" style={{backgroundColor:category.tone}}>{category.emoji}</div><h3 className="mt-3 text-sm font-extrabold">{category.name}</h3><p className="mt-1 text-xs text-[#777487]">{category.description}</p></Link>)}
          </div>
        </div>
      </section>

      <section className="section bg-[#fff0e3]">
        <div className="container">
          <div className="section-heading"><div><span className="eyebrow">A few crowd-pleasers</span><h2>Popular with pet parents</h2><p>Discover the goodies everyone is talking about.</p></div><Link className="text-sm font-extrabold text-[#d96f32]" href="/shop">Shop all <ArrowRight className="ml-1 inline" size={16}/></Link></div>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {featuredProducts.map((product) => <article className="product-card" key={product.id}><div className="product-art relative" style={{backgroundColor:product.tone}}>{product.emoji}{product.label && <span className="absolute left-3 top-3 rounded-full bg-white px-3 py-1 text-[10px] font-black">{product.label}</span>}<button aria-label={`Add ${product.name} to wishlist`} className="absolute right-3 top-3 grid size-9 place-items-center rounded-full bg-white"><Heart size={16}/></button></div><div className="product-info"><p className="muted">{product.pet}</p><h3 className="mt-2">{product.name}</h3><div className="mt-3 flex items-center justify-between"><span className="price">৳{product.price.toLocaleString("en-BD")}</span><span className="text-xs font-bold">⭐ {product.rating}</span></div></div></article>)}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="grid items-center gap-8 rounded-[32px] bg-[#dff2df] p-7 sm:p-12 lg:grid-cols-[1fr_auto]">
            <div><span className="eyebrow">Good people, good products</span><h2 className="mt-4 max-w-xl text-3xl font-black tracking-[-.04em] sm:text-4xl">Have a pet business? Come join the pack.</h2><p className="mt-3 max-w-xl leading-7 text-[#626c65]">Reach more pet parents, manage your products and grow your business with LOVESONE.</p></div>
            <Link className="btn" href="/vendor/register">Start selling <ArrowRight size={17}/></Link>
          </div>
        </div>
      </section>
    </>
  );
}