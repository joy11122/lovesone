import Link from "next/link";

export default function NotFound() {
  return <section className="container grid min-h-[55vh] place-items-center py-20 text-center"><div><div className="text-7xl">🐾</div><h1 className="mt-5 text-4xl font-black">Oops, wrong pawprint!</h1><p className="mt-3 text-[#777487]">We couldn't find that page.</p><Link className="btn mt-6" href="/">Back home</Link></div></section>;
}