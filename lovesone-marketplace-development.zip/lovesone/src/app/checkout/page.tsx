import { auth } from "../../../auth";
import Link from "next/link";
import { CheckoutForm } from "@/components/storefront/checkout-form";
export const metadata = { title: "Checkout" };
export default async function CheckoutPage() { const session = await auth(); if (!session?.user) return <section className="container py-16"><h1 className="text-3xl font-black">Sign in to checkout</h1><p className="mt-2 text-[#777487]">Your cart will stay on this device while you sign in.</p><Link href="/login?callbackUrl=/checkout" className="btn mt-5">Sign in</Link></section>; return <section className="container py-12"><span className="eyebrow">Almost there</span><h1 className="mt-3 text-4xl font-black">Checkout</h1><p className="mt-2 text-[#777487]">Delivering across Bangladesh · Choose your payment method at checkout</p><div className="mt-8"><CheckoutForm /></div></section>; }
