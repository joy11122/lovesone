import { NextRequest, NextResponse } from "next/server";
import mongoose from "mongoose";
import { auth } from "../../../../auth";
import { connectDatabase } from "@/lib/db";
import { Order } from "@/models/Order";
import { createMarketplaceOrder } from "@/services/marketplace";
import { checkoutSchema } from "@/validations/order";
import { apiError } from "@/lib/http";
import { paymentEnabled } from "@/services/payments/config";
import { startSslcommerzPayment } from "@/services/payments/sslcommerz";
import { startBkashPayment } from "@/services/payments/bkash";
import { startNagadPayment } from "@/services/payments/nagad";

export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id || session.user.role !== "customer") return NextResponse.json({ error: "Customer sign-in required" }, { status: 401 });
    const idempotencyKey = request.headers.get("idempotency-key");
    if (!idempotencyKey || idempotencyKey.length < 16 || idempotencyKey.length > 128) return NextResponse.json({ error: "A valid Idempotency-Key header is required." }, { status: 400 });
    const input = checkoutSchema.parse(await request.json());
    if (!mongoose.isValidObjectId(session.user.id)) return NextResponse.json({ error: "Invalid account session" }, { status: 401 });
    if (input.paymentMethod !== "cod" && !paymentEnabled(input.paymentMethod)) return NextResponse.json({ error: `Selected payment gateway is not configured yet. Please use COD or try again after merchant setup.` }, { status: 503 });
    await connectDatabase();
    const order = await createMarketplaceOrder(new mongoose.Types.ObjectId(session.user.id), input, idempotencyKey);
    if (order.paymentMethod !== input.paymentMethod) return NextResponse.json({ error: "This idempotency key was already used for a different payment method. Start checkout again." }, { status: 409 });
    if (input.paymentMethod === "cod") {
      return NextResponse.json({ order: { id: String(order._id), orderNumber: order.orderNumber, total: order.total, status: order.status } }, { status: 201 });
    }
    if (order.paymentStatus === "failed") return NextResponse.json({ error: "This payment attempt has expired. Start checkout again." }, { status: 409 });
    if (order.paymentStatus === "paid") return NextResponse.json({ order: { id: String(order._id), orderNumber: order.orderNumber, total: order.total, paymentStatus: "paid" } });
    if (order.gatewayData?.redirectUrl) return NextResponse.json({ order: { id: String(order._id), orderNumber: order.orderNumber }, redirectUrl: order.gatewayData.redirectUrl });
    const customer = input.shippingAddress;
    const payment = input.paymentMethod === "sslcommerz"
      ? await startSslcommerzPayment({ orderNumber: order.orderNumber, total: order.total, recipient: customer.recipient, phone: customer.phone, email: customer.email || "", addressLine: customer.addressLine, district: customer.district, area: customer.area })
      : input.paymentMethod === "bkash"
        ? await startBkashPayment({ orderNumber: order.orderNumber, total: order.total, recipient: customer.recipient })
        : await startNagadPayment({ orderNumber: order.orderNumber, total: order.total });
    await Order.updateOne({ _id: order._id, paymentStatus: "pending" }, { $set: { gatewayData: { sessionId: payment.gatewaySessionId, transactionId: payment.gatewayTransactionId, paymentReferenceId: payment.paymentReferenceId, redirectUrl: payment.redirectUrl, initiatedAt: new Date() } } });
    return NextResponse.json({ order: { id: String(order._id), orderNumber: order.orderNumber, total: order.total }, redirectUrl: payment.redirectUrl }, { status: 201 });
  } catch (error) { return apiError(error); }
}

export async function GET(_request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id || session.user.role !== "customer") return NextResponse.json({ error: "Customer sign-in required" }, { status: 401 });
    if (!mongoose.isValidObjectId(session.user.id)) return NextResponse.json({ error: "Invalid account session" }, { status: 401 });
    await connectDatabase();
    const orders = await Order.find({ customerId: session.user.id }).select("orderNumber total paymentMethod paymentStatus status subOrders.createdAt createdAt").sort({ createdAt: -1 }).limit(50).lean();
    return NextResponse.json({ orders });
  } catch (error) { return apiError(error); }
}
