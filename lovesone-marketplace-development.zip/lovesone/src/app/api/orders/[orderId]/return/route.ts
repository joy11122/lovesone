import { NextRequest, NextResponse } from "next/server";
import mongoose from "mongoose";
import { z } from "zod";
import { auth } from "../../../../../../auth";
import { connectDatabase } from "@/lib/db";
import { Order } from "@/models/Order";
const schema = z.object({ reason: z.string().trim().min(10).max(1000) });
export async function POST(request: NextRequest, context: { params: Promise<{ orderId: string }> }) {
  try {
    const session = await auth(); if (!session?.user?.id || session.user.role !== "customer" || !mongoose.isValidObjectId(session.user.id)) return NextResponse.json({ error: "Customer sign-in required" }, { status: 401 });
    const { orderId } = await context.params; if (!mongoose.isValidObjectId(orderId)) return NextResponse.json({ error: "Invalid order ID" }, { status: 400 });
    const parsed = schema.safeParse(await request.json()); if (!parsed.success) return NextResponse.json({ error: "Please provide a return reason", issues: parsed.error.issues }, { status: 400 });
    await connectDatabase(); const order = await Order.findOne({ _id: orderId, customerId: session.user.id }); if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
    if (order.status !== "delivered") return NextResponse.json({ error: "Returns can only be requested for delivered orders" }, { status: 409 });
    if (order.returnRequest?.status && order.returnRequest.status !== "none") return NextResponse.json({ error: "A return request already exists for this order" }, { status: 409 });
    order.set("returnRequest", { status: "requested", reason: parsed.data.reason, requestedAt: new Date() }); await order.save();
    return NextResponse.json({ message: "Return request submitted for review" }, { status: 201 });
  } catch (error) { console.error("Return request failed", error); return NextResponse.json({ error: "Unable to submit return request" }, { status: 500 }); }
}
