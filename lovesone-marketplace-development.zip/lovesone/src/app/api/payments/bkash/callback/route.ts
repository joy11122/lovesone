import { NextRequest, NextResponse } from "next/server";
import { connectDatabase } from "@/lib/db";
import { Order } from "@/models/Order";
import { executeBkashPayment } from "@/services/payments/bkash";
import { markOrderPaid } from "@/services/payments/settlement";
import { appUrl } from "@/services/payments/config";
export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams; const paymentId = params.get("paymentID") || ""; const status = params.get("status") || "";
  await connectDatabase();
  try {
    if (status !== "success" || !paymentId) throw new Error("bKash payment was not completed");
    const order = await Order.findOne({ paymentMethod: "bkash", "gatewayData.sessionId": paymentId }).lean();
    if (!order) throw new Error("Order not found for bKash payment");
    const verified = await executeBkashPayment(paymentId);
    if (verified.merchantInvoiceNumber !== order.orderNumber || verified.currency !== "BDT" || Math.abs(Number(verified.amount) - order.total) > 0.01) throw new Error("bKash payment details do not match this order");
    await markOrderPaid({ provider: "bkash", orderNumber: order.orderNumber, transactionId: verified.trxID || paymentId, amount: Number(verified.amount), currency: verified.currency });
    return NextResponse.redirect(new URL(`/account?payment=success&order=${encodeURIComponent(order.orderNumber)}`, appUrl()));
  } catch {
    // Do not mutate order state on an unverified browser redirect. Reconciliation handles abandoned attempts.
    return NextResponse.redirect(new URL("/account?payment=failed", appUrl()));
  }
}
