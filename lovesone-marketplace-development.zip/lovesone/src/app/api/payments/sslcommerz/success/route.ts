import { NextRequest, NextResponse } from "next/server";
import { connectDatabase } from "@/lib/db";
import { markOrderPaid } from "@/services/payments/settlement";
import { validateSslcommerzPayment } from "@/services/payments/sslcommerz";
import { Order } from "@/models/Order";
import { appUrl } from "@/services/payments/config";

async function handle(request: NextRequest) {
  const params = request.method === "POST" ? await request.formData() : request.nextUrl.searchParams;
  const valId = String(params.get("val_id") || "");
  const orderNumber = String(params.get("tran_id") || "");
  await connectDatabase();
  try {
    if (!valId || !orderNumber) throw new Error("Missing SSLCommerz transaction reference");
    const verified = await validateSslcommerzPayment(valId);
    if (!["VALID", "VALIDATED"].includes(verified.status || "") || verified.tran_id !== orderNumber || verified.currency !== "BDT" || verified.risk_level !== "0") throw new Error("SSLCommerz transaction could not be validated");
    await markOrderPaid({ provider: "sslcommerz", orderNumber, transactionId: verified.val_id || valId, amount: Number(verified.amount), currency: verified.currency });
    return NextResponse.redirect(new URL(`/account?payment=success&order=${encodeURIComponent(orderNumber)}`, appUrl()));
  } catch {
    const order = orderNumber ? await Order.findOne({ orderNumber, paymentMethod: "sslcommerz" }).select("orderNumber").lean() : null;
    return NextResponse.redirect(new URL(`/account?payment=${order ? "pending" : "failed"}`, appUrl()));
  }
}
export const POST = handle;
export const GET = handle;
