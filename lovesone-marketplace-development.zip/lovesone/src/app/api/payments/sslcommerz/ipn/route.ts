import { NextRequest, NextResponse } from "next/server";
import { connectDatabase } from "@/lib/db";
import { markOrderPaid } from "@/services/payments/settlement";
import { validateSslcommerzPayment } from "@/services/payments/sslcommerz";
export async function POST(request: NextRequest) {
  try {
    const form = await request.formData(); const valId = String(form.get("val_id") || ""); const orderNumber = String(form.get("tran_id") || "");
    if (!valId || !orderNumber) return NextResponse.json({ error: "Invalid notification" }, { status: 400 });
    await connectDatabase(); const verified = await validateSslcommerzPayment(valId);
    if (!["VALID", "VALIDATED"].includes(verified.status || "") || verified.tran_id !== orderNumber || verified.currency !== "BDT" || verified.risk_level !== "0") return NextResponse.json({ error: "Payment not validated" }, { status: 400 });
    await markOrderPaid({ provider: "sslcommerz", orderNumber, transactionId: verified.val_id || valId, amount: Number(verified.amount), currency: verified.currency });
    return NextResponse.json({ received: true });
  } catch { return NextResponse.json({ error: "Unable to process payment notification" }, { status: 500 }); }
}
