import { NextResponse } from "next/server";
import { appUrl } from "@/services/payments/config";
export async function POST() {
  return NextResponse.redirect(new URL("/account?payment=cancelled", appUrl()));
}

export const GET = POST;
