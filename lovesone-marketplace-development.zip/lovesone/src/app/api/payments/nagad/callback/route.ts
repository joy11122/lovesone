import { NextRequest, NextResponse } from "next/server";
import { connectDatabase } from "@/lib/db";
import { Order } from "@/models/Order";
import { verifyNagadPayment } from "@/services/payments/nagad";
import { markOrderPaid } from "@/services/payments/settlement";
import { appUrl } from "@/services/payments/config";
export async function GET(request: NextRequest) {
  const params = request.nextUrl.searchParams;
  const referenceId = params.get("payment_ref_id") || params.get("paymentReferenceId") || "";
  const callbackOrderNumber = params.get("order_id") || params.get("orderId") || "";
  await connectDatabase();
  try {
    if (!referenceId) throw new Error("Missing Nagad payment reference");
    const order = await Order.findOne({ ...(callbackOrderNumber ? { orderNumber: callbackOrderNumber } : {}), paymentMethod: "nagad", "gatewayData.paymentReferenceId": referenceId }).lean();
    if (!order) throw new Error("Order not found for Nagad payment");
    const verified = await verifyNagadPayment(referenceId);
    if (verified.orderId !== order.orderNumber || verified.currencyCode !== "050" || Math.abs(Number(verified.amount) - order.total) > 0.01) throw new Error("Nagad payment details do not match this order");
    await markOrderPaid({ provider: "nagad", orderNumber: order.orderNumber, transactionId: verified.issuerPaymentRefNo || referenceId, amount: Number(verified.amount), currency: "BDT" });
    return NextResponse.redirect(new URL(`/account?payment=success&order=${encodeURIComponent(order.orderNumber)}`, appUrl()));
  } catch {
    // Keep the order pending when verification is inconclusive; never release stock on a network error.
    return NextResponse.redirect(new URL("/account?payment=failed", appUrl()));
  }
}
