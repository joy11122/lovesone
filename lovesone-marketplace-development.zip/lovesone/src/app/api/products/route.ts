import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { connectDatabase } from "@/lib/db";
import { Product } from "@/models/Product";
import { apiError } from "@/lib/http";

const querySchema = z.object({
  q: z.string().trim().max(100).optional(),
  pet: z.enum(["cat", "dog", "bird", "fish", "rabbit", "small-pet"]).optional(),
  category: z.string().trim().max(80).optional(),
  page: z.coerce.number().int().min(1).max(1000).default(1),
  limit: z.coerce.number().int().min(1).max(48).default(24),
  sort: z.enum(["newest", "price-asc", "price-desc"]).default("newest")
});

export async function GET(request: NextRequest) {
  try {
    const params = querySchema.parse(Object.fromEntries(request.nextUrl.searchParams));
    await connectDatabase();
    const filter: Record<string, unknown> = { status: "active", deletedAt: null };
    if (params.pet) filter.petTypes = params.pet;
    if (params.category) filter.categorySlug = params.category;
    if (params.q) filter.$text = { $search: params.q };
    const sort = params.sort === "price-asc" ? { price: 1 as const } :
      params.sort === "price-desc" ? { price: -1 as const } : { createdAt: -1 as const };
    const [items, total] = await Promise.all([
      Product.find(filter).select("title slug description petTypes categorySlug price compareAtPrice images vendorId stock createdAt")
        .sort(sort).skip((params.page - 1) * params.limit).limit(params.limit).lean(),
      Product.countDocuments(filter)
    ]);
    return NextResponse.json({ items, pagination: { page: params.page, limit: params.limit, total, pages: Math.ceil(total / params.limit) } });
  } catch (error) {
    return apiError(error);
  }
}
