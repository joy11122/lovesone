import { NextRequest, NextResponse } from "next/server";
import { connectDatabase } from "@/lib/db";
import { Product } from "@/models/Product";
import { apiError } from "@/lib/http";
export async function GET(_request: NextRequest, context: { params: Promise<{ slug: string }> }) { try { const { slug } = await context.params; if (!/^[a-z0-9-]{2,180}$/.test(slug)) return NextResponse.json({ error: "Product not found" }, { status: 404 }); await connectDatabase(); const product = await Product.findOne({ slug, status: "active", deletedAt: null }).select("title slug description petTypes categorySlug price compareAtPrice images vendorId stock medicine").populate("vendorId", "name").lean(); if (!product) return NextResponse.json({ error: "Product not found" }, { status: 404 }); return NextResponse.json({ product }); } catch (error) { return apiError(error); } }
