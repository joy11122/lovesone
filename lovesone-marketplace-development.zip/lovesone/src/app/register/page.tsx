"use client";

import { useState } from "react";
import Link from "next/link";

export default function RegisterPage() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await response.json();
      setMessage(response.ok ? "Account created. You can now sign in." : (data.error || "Registration failed."));
    } catch {
      setMessage("Unable to connect. Please try again.");
    } finally { setBusy(false); }
  }

  return <section className="container grid min-h-[65vh] place-items-center py-16">
    <form onSubmit={submit} className="w-full max-w-md rounded-[30px] border border-[#f0e9e1] bg-white p-8 shadow-sm">
      <div className="text-center"><div className="text-5xl">🐾</div><h1 className="mt-4 text-3xl font-black">Join the pack</h1><p className="mt-2 text-sm text-[#777487]">Create your LOVESONE account.</p></div>
      <label className="mt-6 block text-sm font-bold">Your name<input required minLength={2} maxLength={100} autoComplete="name" className="mt-2 w-full rounded-xl border border-[#e9e2da] px-4 py-3 outline-none focus:border-[#ff914d]" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>
      <label className="mt-4 block text-sm font-bold">Email<input required type="email" autoComplete="email" className="mt-2 w-full rounded-xl border border-[#e9e2da] px-4 py-3 outline-none focus:border-[#ff914d]" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label>
      <label className="mt-4 block text-sm font-bold">Password<input required type="password" minLength={10} maxLength={128} autoComplete="new-password" className="mt-2 w-full rounded-xl border border-[#e9e2da] px-4 py-3 outline-none focus:border-[#ff914d]" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/><span className="mt-1 block text-xs font-normal text-[#777487]">Use at least 10 characters.</span></label>
      {message && <p role="status" className="mt-4 rounded-xl bg-[#fff0e3] p-3 text-sm">{message}</p>}
      <button disabled={busy} className="btn mt-6 w-full disabled:opacity-50">{busy ? "Creating account…" : "Create account"}</button>
      <p className="mt-5 text-center text-sm text-[#777487]">Already have an account? <Link className="font-bold text-[#d96f32]" href="/login">Sign in</Link></p>
    </form>
  </section>;
}
