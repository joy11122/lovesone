"use client";

import { useState } from "react";
import Link from "next/link";
import { signIn } from "next-auth/react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function credentialsSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    const result = await signIn("credentials", { email, password, redirect: false, callbackUrl: "/" });
    setBusy(false);
    if (result?.error) setError("Email or password is incorrect.");
    else window.location.assign(result?.url || "/");
  }

  return <section className="container grid min-h-[65vh] place-items-center py-16">
    <div className="w-full max-w-md rounded-[30px] border border-[#f0e9e1] bg-white p-8 shadow-sm">
      <div className="text-center"><div className="text-5xl">🐾</div><h1 className="mt-4 text-3xl font-black">Welcome back!</h1><p className="mt-2 text-sm text-[#777487]">Your pet's happy place is waiting.</p></div>
      <button onClick={() => signIn("google", { callbackUrl: "/" })} className="mt-7 w-full rounded-full border border-[#e9e2da] px-4 py-3 text-sm font-extrabold hover:bg-[#fff8ef]">Continue with Google</button>
      <div className="my-5 flex items-center gap-3 text-xs text-[#999]"><span className="h-px flex-1 bg-[#eee6dd]"/>OR EMAIL<span className="h-px flex-1 bg-[#eee6dd]"/></div>
      <form onSubmit={credentialsSubmit}>
        <label className="block text-sm font-bold">Email<input required type="email" autoComplete="email" className="mt-2 w-full rounded-xl border border-[#e9e2da] px-4 py-3 outline-none focus:border-[#ff914d]" value={email} onChange={e=>setEmail(e.target.value)}/></label>
        <label className="mt-4 block text-sm font-bold">Password<input required type="password" autoComplete="current-password" className="mt-2 w-full rounded-xl border border-[#e9e2da] px-4 py-3 outline-none focus:border-[#ff914d]" value={password} onChange={e=>setPassword(e.target.value)}/></label>
        {error && <p role="alert" className="mt-4 rounded-xl bg-[#fff0e3] p-3 text-sm">{error}</p>}
        <button disabled={busy} className="btn mt-6 w-full disabled:opacity-50">{busy ? "Signing in…" : "Sign in"}</button>
      </form>
      <p className="mt-5 text-center text-sm text-[#777487]">New to the pack? <Link className="font-bold text-[#d96f32]" href="/register">Create an account</Link></p>
    </div>
  </section>;
}
