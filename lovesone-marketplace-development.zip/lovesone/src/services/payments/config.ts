import "server-only";
import type { OnlinePaymentProvider } from "./types";

export function appUrl() {
  const value = process.env.NEXT_PUBLIC_APP_URL;
  if (!value) throw new Error("NEXT_PUBLIC_APP_URL is not configured");
  const url = new URL(value);
  if (process.env.NODE_ENV === "production" && url.protocol !== "https:") {
    throw new Error("NEXT_PUBLIC_APP_URL must use HTTPS in production");
  }
  return url.origin;
}

export function paymentEnabled(provider: OnlinePaymentProvider) {
  if (provider === "sslcommerz") return Boolean(process.env.SSLCOMMERZ_STORE_ID && process.env.SSLCOMMERZ_STORE_PASSWORD);
  if (provider === "bkash") return Boolean(process.env.BKASH_APP_KEY && process.env.BKASH_APP_SECRET && process.env.BKASH_USERNAME && process.env.BKASH_PASSWORD);
  return Boolean(process.env.NAGAD_MERCHANT_ID && process.env.NAGAD_MERCHANT_NUMBER && process.env.NAGAD_MERCHANT_PRIVATE_KEY && process.env.NAGAD_GATEWAY_PUBLIC_KEY && process.env.NAGAD_SERVER_IP && process.env.NAGAD_BASE_URL);
}

export function requirePaymentConfig(provider: OnlinePaymentProvider) {
  if (!paymentEnabled(provider)) throw new Error(`${provider} payments are not configured. Add the merchant credentials first.`);
}

export function paymentBaseUrl(provider: OnlinePaymentProvider) {
  if (provider === "sslcommerz") return process.env.SSLCOMMERZ_BASE_URL || (process.env.SSLCOMMERZ_SANDBOX === "false" ? "https://securepay.sslcommerz.com" : "https://sandbox.sslcommerz.com");
  if (provider === "bkash") return process.env.BKASH_BASE_URL || (process.env.BKASH_SANDBOX === "false" ? "https://tokenized.pay.bka.sh/v1.2.0-beta" : "https://tokenized.sandbox.bka.sh/v1.2.0-beta");
  if (!process.env.NAGAD_BASE_URL) throw new Error("NAGAD_BASE_URL must be set to the endpoint supplied during merchant onboarding");
  return process.env.NAGAD_BASE_URL.replace(/\/$/, "");
}
