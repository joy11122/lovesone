export type OnlinePaymentProvider = "sslcommerz" | "bkash" | "nagad";

export type PaymentStart = {
  redirectUrl: string;
  gatewaySessionId?: string;
  gatewayTransactionId?: string;
  paymentReferenceId?: string;
};

export type VerifiedPayment = {
  provider: OnlinePaymentProvider;
  orderNumber: string;
  transactionId: string;
  amount: number;
  currency: string;
};
