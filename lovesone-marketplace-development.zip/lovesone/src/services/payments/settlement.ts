import "server-only";
import mongoose from "mongoose";
import { Order } from "@/models/Order";
import { Product } from "@/models/Product";
import type { OnlinePaymentProvider } from "./types";

export async function markOrderPaid(input: {
  provider: OnlinePaymentProvider; orderNumber: string; transactionId: string; amount: number; currency: string;
}) {
  if (input.currency !== "BDT" || !Number.isFinite(input.amount) || input.amount <= 0) throw new Error("Invalid payment amount or currency");
  const session = await mongoose.startSession();
  try {
    let matched = false;
    await session.withTransaction(async () => {
      const order = await Order.findOne({ orderNumber: input.orderNumber, paymentMethod: input.provider }).session(session);
      if (!order) throw new Error("Order not found for this payment");
      if (Math.abs(order.total - input.amount) > 0.01) throw new Error("Payment amount does not match the order total");
      if (order.paymentStatus === "paid") {
        if (order.gatewayData?.transactionId && order.gatewayData.transactionId !== input.transactionId) throw new Error("Order is already paid with a different transaction reference");
        matched = true; return;
      }
      if (order.paymentStatus !== "pending") throw new Error("Order is not awaiting payment");
      const result = await Order.updateOne(
        { _id: order._id, paymentStatus: "pending", paymentMethod: input.provider },
        { $set: { paymentStatus: "paid", "gatewayData.transactionId": input.transactionId, "gatewayData.verifiedAt": new Date() } },
        { session }
      );
      matched = result.modifiedCount === 1;
    });
    return matched;
  } finally { await session.endSession(); }
}

export async function markOrderPaymentFailed(orderNumber: string, provider: OnlinePaymentProvider, reason: string) {
  const session = await mongoose.startSession();
  try {
    await session.withTransaction(async () => {
      const order = await Order.findOneAndUpdate(
        { orderNumber, paymentMethod: provider, paymentStatus: "pending" },
        { $set: { paymentStatus: "failed", status: "cancelled", "subOrders.$[].status": "cancelled", "gatewayData.failureReason": reason.slice(0, 300) } },
        { new: true, session }
      );
      if (!order) return;
      for (const subOrder of order.subOrders) {
        for (const item of subOrder.items) {
          await Product.updateOne({ _id: item.productId }, { $inc: { stock: item.quantity } }, { session });
        }
      }
    });
  } finally { await session.endSession(); }
}
