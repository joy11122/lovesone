import "server-only";
import { appUrl, paymentBaseUrl, requirePaymentConfig } from "./config";
import type { PaymentStart } from "./types";

export async function startSslcommerzPayment(order: { orderNumber: string; total: number; recipient: string; phone: string; email: string; addressLine: string; district: string; area: string }) : Promise<PaymentStart> {
  requirePaymentConfig("sslcommerz");
  if (order.total < 10 || order.total > 500000) throw new Error("SSLCommerz supports transaction amounts from ৳10 to ৳500,000.");
  const base = paymentBaseUrl("sslcommerz");
  const body = new URLSearchParams({
    store_id: process.env.SSLCOMMERZ_STORE_ID!, store_passwd: process.env.SSLCOMMERZ_STORE_PASSWORD!,
    total_amount: order.total.toFixed(2), currency: "BDT", tran_id: order.orderNumber,
    product_category: "pet-supplies", product_name: "LOVESONE marketplace order", product_profile: "general",
    cus_name: order.recipient, cus_email: order.email, cus_add1: order.addressLine, cus_city: order.district, cus_state: order.area, cus_country: "Bangladesh", cus_phone: order.phone,
    shipping_method: "NO", num_of_item: "1", success_url: `${appUrl()}/api/payments/sslcommerz/success`, fail_url: `${appUrl()}/api/payments/sslcommerz/fail`,
    cancel_url: `${appUrl()}/api/payments/sslcommerz/cancel`, ipn_url: `${appUrl()}/api/payments/sslcommerz/ipn`
  });
  const response = await fetch(`${base}/gwprocess/v4/api.php`, { method: "POST", body, signal: AbortSignal.timeout(30_000) });
  const data = await response.json() as { status?: string; GatewayPageURL?: string; sessionkey?: string; failedreason?: string };
  if (!response.ok || data.status !== "SUCCESS" || !data.GatewayPageURL) throw new Error(data.failedreason || "Unable to create SSLCommerz payment session");
  return { redirectUrl: data.GatewayPageURL, gatewaySessionId: data.sessionkey };
}

export async function validateSslcommerzPayment(valId: string) {
  requirePaymentConfig("sslcommerz");
  const url = new URL(`${paymentBaseUrl("sslcommerz")}/validator/api/validationserverAPI.php`);
  url.search = new URLSearchParams({ val_id: valId, store_id: process.env.SSLCOMMERZ_STORE_ID!, store_passwd: process.env.SSLCOMMERZ_STORE_PASSWORD!, format: "json" }).toString();
  const response = await fetch(url, { cache: "no-store", signal: AbortSignal.timeout(30_000) });
  if (!response.ok) throw new Error("SSLCommerz validation service is unavailable");
  return await response.json() as { status?: string; tran_id?: string; amount?: string; currency?: string; risk_level?: string; val_id?: string };
}
