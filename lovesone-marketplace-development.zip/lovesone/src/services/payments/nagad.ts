import "server-only";
import { constants, createSign, createVerify, privateDecrypt, publicEncrypt, randomBytes } from "node:crypto";
import { appUrl, paymentBaseUrl, requirePaymentConfig } from "./config";
import type { PaymentStart } from "./types";

function pem(value: string) { return value.replace(/\\n/g, "\n").trim(); }
function encryptSensitive(value: string) {
  return publicEncrypt({ key: pem(process.env.NAGAD_GATEWAY_PUBLIC_KEY!), padding: constants.RSA_PKCS1_PADDING }, Buffer.from(value)).toString("base64");
}
function signSensitive(value: string) {
  const signer = createSign("RSA-SHA1"); signer.update(value); signer.end();
  return signer.sign(pem(process.env.NAGAD_MERCHANT_PRIVATE_KEY!), "base64");
}
function verifyGatewaySignature(value: string, signature: string) {
  const verifier = createVerify("RSA-SHA1"); verifier.update(value); verifier.end();
  return verifier.verify(pem(process.env.NAGAD_GATEWAY_PUBLIC_KEY!), signature, "base64");
}
function decryptSensitive(value: string) {
  // Node 22/OpenSSL 3 disables PKCS#1 v1.5 private decryption. Decrypt the RSA
  // block without padding and validate the provider-mandated 00 02 PS 00 M frame.
  const encoded = privateDecrypt({ key: pem(process.env.NAGAD_MERCHANT_PRIVATE_KEY!), padding: constants.RSA_NO_PADDING }, Buffer.from(value, "base64"));
  let separator = 0;
  let foundSeparator = 0;
  let invalid = encoded[0] | (encoded[1] ^ 2);
  for (let index = 2; index < encoded.length; index += 1) {
    const isZero = Number(encoded[index] === 0);
    if (isZero && foundSeparator === 0) {
      separator = index;
      foundSeparator = 1;
    }
  }
  invalid |= Number(foundSeparator !== 1 || separator < 10);
  if (invalid !== 0) throw new Error("Invalid Nagad encrypted response block");
  return encoded.subarray(separator + 1).toString("utf8");
}

export async function startNagadPayment(order: { orderNumber: string; total: number }): Promise<PaymentStart> {
  requirePaymentConfig("nagad");
  const base = paymentBaseUrl("nagad"); const merchantId = process.env.NAGAD_MERCHANT_ID!;
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Dhaka", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23" }).formatToParts(new Date());
  const dateTime = ["year", "month", "day", "hour", "minute", "second"].map((key) => parts.find((part) => part.type === key)?.value || "00").join("");
  const challenge = randomBytes(20).toString("hex");
  const initPayload = JSON.stringify({ merchantId, datetime: dateTime, orderId: order.orderNumber, challenge });
  const headers = { "Content-Type": "application/json", "X-KM-Api-Version": "v-0.2.0", "X-KM-Client-Type": "PC_WEB", "X-KM-IP-V4": process.env.NAGAD_SERVER_IP! };
  const initResponse = await fetch(`${base}/api/dfs/check-out/initialize/${merchantId}/${encodeURIComponent(order.orderNumber)}`, {
    method: "POST", headers, signal: AbortSignal.timeout(30_000),
    body: JSON.stringify({ accountNumber: process.env.NAGAD_MERCHANT_NUMBER, dateTime, sensitiveData: encryptSensitive(initPayload), signature: signSensitive(initPayload) })
  });
  const init = await initResponse.json() as { sensitiveData?: string; signature?: string; message?: string };
  if (!initResponse.ok || !init.sensitiveData || !init.signature) throw new Error(init.message || "Nagad initialization failed");
  const handshakeJson = decryptSensitive(init.sensitiveData);
  if (!verifyGatewaySignature(handshakeJson, init.signature)) throw new Error("Nagad initialization signature is invalid");
  const handshake = JSON.parse(handshakeJson) as { paymentReferenceId?: string; challenge?: string };
  if (!handshake.paymentReferenceId || !handshake.challenge) throw new Error("Nagad returned an invalid payment handshake");
  const orderPayload = JSON.stringify({ merchantId, orderId: order.orderNumber, currencyCode: "050", amount: order.total.toFixed(2), challenge: handshake.challenge });
  const completeResponse = await fetch(`${base}/api/dfs/check-out/complete/${encodeURIComponent(handshake.paymentReferenceId)}`, {
    method: "POST", headers, signal: AbortSignal.timeout(30_000),
    body: JSON.stringify({ sensitiveData: encryptSensitive(orderPayload), signature: signSensitive(orderPayload), merchantCallbackURL: `${appUrl()}/api/payments/nagad/callback` })
  });
  const complete = await completeResponse.json() as { callBackUrl?: string; status?: string; message?: string };
  if (!completeResponse.ok || !complete.callBackUrl) throw new Error(complete.message || "Nagad checkout could not be created");
  return { redirectUrl: complete.callBackUrl, gatewaySessionId: handshake.paymentReferenceId, paymentReferenceId: handshake.paymentReferenceId };
}

export async function verifyNagadPayment(referenceId: string) {
  requirePaymentConfig("nagad");
  const response = await fetch(`${paymentBaseUrl("nagad")}/api/dfs/verify/payment/${encodeURIComponent(referenceId)}`, { headers: { "X-KM-Api-Version": "v-0.2.0", "X-KM-Client-Type": "PC_WEB" }, cache: "no-store", signal: AbortSignal.timeout(30_000) });
  const data = await response.json() as { status?: string; orderId?: string; amount?: string; issuerPaymentRefNo?: string; paymentReferenceId?: string; currencyCode?: string; message?: string };
  if (!response.ok || data.status !== "Success") throw new Error(data.message || "Nagad payment verification failed");
  return data;
}
