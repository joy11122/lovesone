import "server-only";
import { appUrl, paymentBaseUrl, requirePaymentConfig } from "./config";
import type { PaymentStart } from "./types";

async function grantToken() {
  requirePaymentConfig("bkash");
  const base = paymentBaseUrl("bkash");
  const response = await fetch(`${base}/tokenized/checkout/token/grant`, {
    method: "POST", signal: AbortSignal.timeout(30_000),
    headers: {
      "Content-Type": "application/json", Accept: "application/json",
      username: process.env.BKASH_USERNAME!, password: process.env.BKASH_PASSWORD!,
      "X-App-Key": process.env.BKASH_APP_KEY!
    },
    body: JSON.stringify({ app_key: process.env.BKASH_APP_KEY, app_secret: process.env.BKASH_APP_SECRET })
  });
  const data = await response.json() as { id_token?: string; statusCode?: string; statusMessage?: string };
  if (!response.ok || !data.id_token) throw new Error(data.statusMessage || "bKash authentication failed");
  return data.id_token;
}

export async function startBkashPayment(order: { orderNumber: string; total: number; recipient: string }): Promise<PaymentStart> {
  const token = await grantToken();
  const base = paymentBaseUrl("bkash");
  const response = await fetch(`${base}/tokenized/checkout/create`, {
    method: "POST", signal: AbortSignal.timeout(30_000),
    headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: token, "X-App-Key": process.env.BKASH_APP_KEY! },
    body: JSON.stringify({
      mode: "0011", payerReference: order.orderNumber, callbackURL: `${appUrl()}/api/payments/bkash/callback`,
      amount: order.total.toFixed(2), currency: "BDT", intent: "sale", merchantInvoiceNumber: order.orderNumber
    })
  });
  const data = await response.json() as { paymentID?: string; bkashURL?: string; statusMessage?: string };
  if (!response.ok || !data.paymentID || !data.bkashURL) throw new Error(data.statusMessage || "Unable to create bKash payment");
  return { redirectUrl: data.bkashURL, gatewaySessionId: data.paymentID, gatewayTransactionId: data.paymentID };
}

export async function executeBkashPayment(paymentId: string) {
  const token = await grantToken();
  const base = paymentBaseUrl("bkash");
  const response = await fetch(`${base}/tokenized/checkout/execute`, {
    method: "POST", signal: AbortSignal.timeout(30_000),
    headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: token, "X-App-Key": process.env.BKASH_APP_KEY! },
    body: JSON.stringify({ paymentID: paymentId })
  });
  const data = await response.json() as { statusCode?: string; transactionStatus?: string; paymentID?: string; trxID?: string; amount?: string; currency?: string; merchantInvoiceNumber?: string; statusMessage?: string };
  if (!response.ok || data.statusCode !== "0000" || data.transactionStatus !== "Completed") throw new Error(data.statusMessage || "bKash payment could not be verified");
  return data;
}
