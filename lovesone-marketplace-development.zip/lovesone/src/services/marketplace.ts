import mongoose from "mongoose";
import { Product } from "@/models/Product";
import { Order } from "@/models/Order";
import { VendorProfile } from "@/models/VendorProfile";
import { randomUUID } from "node:crypto";
import type { CheckoutInput } from "@/validations/order";

/**
 * Core checkout transaction. Call only after authenticating the customer and
 * deriving customerId on the server. Prices/vendor IDs are read from MongoDB,
 * never accepted from the browser.
 */
export async function createMarketplaceOrder(
  customerId: mongoose.Types.ObjectId,
  input: CheckoutInput,
  idempotencyKey: string
) {
  const existing = await Order.findOne({ idempotencyKey, customerId });
  if (existing) return existing;

  const session = await mongoose.startSession();
  try {
    let createdOrder: InstanceType<typeof Order> | null = null;
    await session.withTransaction(async () => {
      const productIds = [...new Set(input.items.map((item) => item.productId))];
      const products = await Product.find({
        _id: { $in: productIds },
        status: "active",
        deletedAt: null
      }).session(session);
      if (products.length !== productIds.length) throw new Error("One or more products are unavailable");

      const productMap = new Map(products.map((product) => [String(product._id), product]));
      const grouped = new Map<string, { vendorId: mongoose.Types.ObjectId; items: Array<{ productId: mongoose.Types.ObjectId; titleSnapshot: string; quantity: number; unitPrice: number }>; subtotal: number }>();

      for (const item of input.items) {
        const product = productMap.get(item.productId);
        if (!product || product.stock < item.quantity) throw new Error("Insufficient stock");
        if (product.medicine?.requiresPrescription) throw new Error("Prescription verification is required before checkout");
        const vendorKey = String(product.vendorId);
        const group = grouped.get(vendorKey) ?? { vendorId: product.vendorId, items: [], subtotal: 0 };
        group.items.push({ productId: product._id, titleSnapshot: product.title, quantity: item.quantity, unitPrice: product.price });
        group.subtotal += product.price * item.quantity;
        grouped.set(vendorKey, group);
      }

      const subOrders = [];
      let total = 0;
      for (const group of grouped.values()) {
        const vendor = await VendorProfile.findOne({
          userId: group.vendorId,
          verificationStatus: "verified"
        }).session(session);
        if (!vendor) throw new Error("A seller is not currently eligible to receive orders");
        const commissionRate = vendor.commissionRate;
        const commissionAmount = Math.round(group.subtotal * commissionRate) / 100;
        total += group.subtotal;
        subOrders.push({ ...group, commissionAmount, vendorNetAmount: group.subtotal - commissionAmount });
      }

      for (const item of input.items) {
        const update = await Product.updateOne(
          { _id: item.productId, stock: { $gte: item.quantity }, status: "active" },
          { $inc: { stock: -item.quantity } },
          { session }
        );
        if (update.modifiedCount !== 1) throw new Error("Stock changed during checkout; please retry");
      }

      const [order] = await Order.create([{
        orderNumber: `LV-${randomUUID().slice(0, 12).toUpperCase()}`,
        customerId, subOrders, total, paymentMethod: input.paymentMethod,
        shippingAddress: input.shippingAddress, idempotencyKey
      }], { session });
      createdOrder = order;
    });
    if (!createdOrder) throw new Error("Order could not be created");
    return createdOrder;
  } finally {
    await session.endSession();
  }
}
