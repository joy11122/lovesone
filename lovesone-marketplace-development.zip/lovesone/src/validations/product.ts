import { z } from "zod";

export const productInputSchema = z.object({
  title: z.string().trim().min(3).max(120),
  description: z.string().trim().min(20).max(5000),
  petTypes: z.array(z.enum(["cat", "dog", "bird", "fish", "rabbit", "small-pet"])).min(1),
  categorySlug: z.string().trim().min(2).max(80),
  price: z.number().positive().max(10000000),
  compareAtPrice: z.number().positive().optional(),
  sku: z.string().trim().min(2).max(64),
  stock: z.number().int().min(0).max(1000000),
  images: z.array(z.string().url()).max(8).default([]),
  medicine: z.object({
    isMedicine: z.boolean(),
    requiresPrescription: z.boolean()
  }).optional(),
  status: z.enum(["draft", "pending-review"]).default("pending-review")
});
export type ProductInput = z.infer<typeof productInputSchema>;
