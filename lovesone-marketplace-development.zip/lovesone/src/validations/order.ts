import { z } from "zod";

export const checkoutSchema = z.object({
  items: z.array(z.object({
    productId: z.string().regex(/^[a-f\d]{24}$/i),
    variantId: z.string().regex(/^[a-f\d]{24}$/i).optional(),
    quantity: z.number().int().min(1).max(50)
  })).min(1).max(50),
  shippingAddress: z.object({
    recipient: z.string().trim().min(2).max(100),
    phone: z.string().trim().regex(/^(?:\+?88)?01[3-9]\d{8}$/),
    email: z.string().trim().email().max(254).optional().or(z.literal("")),
    addressLine: z.string().trim().min(8).max(300),
    district: z.string().trim().min(2).max(80),
    area: z.string().trim().min(2).max(80)
  }),
  paymentMethod: z.enum(["cod", "sslcommerz", "bkash", "nagad"])
}).superRefine((value, context) => {
  if (value.paymentMethod === "sslcommerz" && !value.shippingAddress.email) context.addIssue({ code: "custom", path: ["shippingAddress", "email"], message: "Email is required for card and mobile banking checkout." });
});
export type CheckoutInput = z.infer<typeof checkoutSchema>;
