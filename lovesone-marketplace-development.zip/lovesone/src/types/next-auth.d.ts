import "next-auth";
declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: "customer" | "vendor" | "support" | "admin" | "super-admin";
    } & NonNullable<DefaultSession["user"]>;
  }
  interface User {
    role?: "customer" | "vendor" | "support" | "admin" | "super-admin";
  }
}
declare module "next-auth/jwt" {
  interface JWT { role?: string; }
}
import type { DefaultSession } from "next-auth";
