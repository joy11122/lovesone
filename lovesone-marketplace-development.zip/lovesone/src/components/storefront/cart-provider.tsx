"use client";

import Link from "next/link";
import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type CartProduct = { id: string; slug: string; title: string; price: number; image?: string; vendorId: string; stock: number };
type CartLine = { product: CartProduct; quantity: number };
type CartContextValue = { lines: CartLine[]; count: number; subtotal: number; add: (product: CartProduct, quantity?: number) => void; setQuantity: (id: string, quantity: number) => void; remove: (id: string) => void; clear: () => void };
const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "lovesone-cart-v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed: unknown = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          const safeLines = parsed.filter((line): line is CartLine => Boolean(line && typeof line === "object" && "product" in line && "quantity" in line && line.product && typeof line.product === "object" && typeof line.product.id === "string" && typeof line.product.slug === "string" && typeof line.product.title === "string" && Number.isFinite(line.product.price) && line.product.price >= 0 && Number.isInteger(line.quantity) && line.quantity > 0 && Number.isInteger(line.product.stock) && line.product.stock >= line.quantity));
          setLines(safeLines);
        }
      }
    } catch { window.localStorage.removeItem(STORAGE_KEY); }
    setReady(true);
  }, []);
  useEffect(() => { if (ready) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(lines)); }, [lines, ready]);
  const value = useMemo<CartContextValue>(() => ({
    lines,
    count: lines.reduce((sum, line) => sum + line.quantity, 0),
    subtotal: lines.reduce((sum, line) => sum + line.product.price * line.quantity, 0),
    add(product, quantity = 1) { setLines(current => { const found = current.find(line => line.product.id === product.id); if (found) return current.map(line => line.product.id === product.id ? { ...line, quantity: Math.min(product.stock, line.quantity + quantity) } : line); return [...current, { product, quantity: Math.min(product.stock, quantity) }]; }); },
    setQuantity(id, quantity) { setLines(current => current.flatMap(line => line.product.id !== id ? [line] : quantity <= 0 ? [] : [{ ...line, quantity: Math.min(line.product.stock, Math.floor(quantity)) }])); },
    remove(id) { setLines(current => current.filter(line => line.product.id !== id)); },
    clear() { setLines([]); }
  }), [lines]);
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
export function useCart() { const value = useContext(CartContext); if (!value) throw new Error("useCart must be used inside CartProvider"); return value; }

export function AddToCartButton({ product, quantity = 1, className = "btn" }: { product: CartProduct; quantity?: number; className?: string }) {
  const { add } = useCart(); const [added, setAdded] = useState(false);
  return <button type="button" disabled={product.stock < 1} className={`${className} disabled:cursor-not-allowed disabled:opacity-50`} onClick={() => { add(product, quantity); setAdded(true); window.setTimeout(() => setAdded(false), 1400); }}>{product.stock < 1 ? "Out of stock" : added ? "Added to bag ✓" : "Add to bag"}</button>;
}

export function CartHeaderLink() { const { count } = useCart(); return <Link href="/cart" aria-label={`Shopping cart, ${count} items`} className="relative grid size-10 place-items-center rounded-full bg-[#ff914d] text-sm font-black">🛍️{count > 0 && <span className="absolute -right-1 -top-1 grid size-5 place-items-center rounded-full bg-[#27233a] text-[10px] text-white">{count > 99 ? "99+" : count}</span>}</Link>; }
