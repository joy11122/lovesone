import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="bg-[#27233a] py-12 text-white">
      <div className="container grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Link href="/" className="text-2xl font-black tracking-[-.06em]">LOVES<span className="text-[#ff914d]">ONE</span> 🐾</Link>
          <p className="mt-3 max-w-xs text-sm leading-6 text-white/65">A happier little corner for pets and the people who love them.</p>
        </div>
        <div><h3 className="font-extrabold">Explore</h3><div className="mt-3 grid gap-2 text-sm text-white/65"><Link href="/shop">Shop all</Link><Link href="/shop?category=food">Food & treats</Link><Link href="/shop?category=toys">Toys & play</Link></div></div>
        <div><h3 className="font-extrabold">Sell on LOVESONE</h3><div className="mt-3 grid gap-2 text-sm text-white/65"><Link href="/vendor/register">Become a seller</Link><Link href="/vendor/help">Seller help</Link></div></div>
        <div><h3 className="font-extrabold">Need a paw?</h3><p className="mt-3 text-sm text-white/65">Customer support, delivery information and returns.</p><p className="mt-3 text-sm font-bold text-[#ffd166]">hello@lovesone.example</p></div>
      </div>
      <div className="container mt-10 border-t border-white/15 pt-5 text-xs text-white/50">© {new Date().getFullYear()} LOVESONE. Made with love for every pet.</div>
    </footer>
  );
}