"use client";

import { useState, type FormEvent } from "react";

type ProductRow = { _id: string; title: string; sku: string; price: number; stock: number; status: string; categorySlug: string };
type OrderRow = { _id: string; orderNumber: string; total: number; status: string; paymentMethod: string; paymentStatus: string; createdAt: string; subOrders: Array<{ vendorId: string; status: string; subtotal: number; items: Array<{ titleSnapshot: string; quantity: number }> }> };

export function VendorProductForm() {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage("");
    const formElement = event.currentTarget;
    const form = new FormData(formElement);
    const payload = { title: String(form.get("title")), description: String(form.get("description")), categorySlug: String(form.get("categorySlug")), petTypes: form.getAll("petTypes"), price: Number(form.get("price")), sku: String(form.get("sku")), stock: Number(form.get("stock")), images: [] };
    try {
      const response = await fetch("/api/vendor/products", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const data = await response.json() as { message?: string; error?: string };
      if (!response.ok) throw new Error(data.error || "Could not submit product");
      setMessage(data.message || "Listing submitted for review."); formElement.reset(); window.location.reload();
    } catch (error) { setMessage(error instanceof Error ? error.message : "Something went wrong"); }
    finally { setBusy(false); }
  }
  return <form onSubmit={submit} className="grid gap-4 rounded-3xl border border-[#f0e9e1] bg-white p-6 sm:grid-cols-2">
    <div className="sm:col-span-2"><h2 className="text-xl font-black">Add a product</h2><p className="mt-1 text-sm text-[#777487]">Every new listing is reviewed before appearing in the shop.</p></div>
    <label className="text-sm font-bold">Product name<input name="title" required maxLength={120} className="mt-2 w-full rounded-xl border border-[#eee5dc] px-4 py-3 font-normal" placeholder="e.g. Salmon dog food" /></label>
    <label className="text-sm font-bold">Category slug<input name="categorySlug" required className="mt-2 w-full rounded-xl border border-[#eee5dc] px-4 py-3 font-normal" placeholder="food, toys, accessories" /></label>
    <label className="text-sm font-bold">SKU<input name="sku" required className="mt-2 w-full rounded-xl border border-[#eee5dc] px-4 py-3 font-normal" /></label>
    <label className="text-sm font-bold">Price (৳)<input name="price" type="number" min="0.01" step="0.01" required className="mt-2 w-full rounded-xl border border-[#eee5dc] px-4 py-3 font-normal" /></label>
    <label className="text-sm font-bold">Stock quantity<input name="stock" type="number" min="0" step="1" required className="mt-2 w-full rounded-xl border border-[#eee5dc] px-4 py-3 font-normal" /></label>
    <fieldset className="text-sm"><legend className="font-bold">Suitable for</legend><div className="mt-3 flex flex-wrap gap-3">{["cat","dog","bird","fish","rabbit","small-pet"].map(pet=><label key={pet} className="flex items-center gap-2 font-normal"><input type="checkbox" name="petTypes" value={pet} />{pet}</label>)}</div></fieldset>
    <label className="text-sm font-bold sm:col-span-2">Description<textarea name="description" required maxLength={5000} rows={3} className="mt-2 w-full rounded-xl border border-[#eee5dc] px-4 py-3 font-normal" /></label>
    <div className="flex flex-wrap items-center gap-3 sm:col-span-2"><button disabled={busy} className="btn disabled:opacity-50">{busy ? "Submitting…" : "Submit for review"}</button>{message && <p role="status" className="text-sm text-[#a45b2d]">{message}</p>}</div>
  </form>;
}

export function VendorOrders({ orders }: { orders: OrderRow[] }) {
  const [busyId, setBusyId] = useState("");
  const [notice, setNotice] = useState("");
  async function update(orderId: string, status: string) {
    setBusyId(orderId); setNotice("");
    try {
      const response = await fetch("/api/vendor/orders", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ orderId, status }) });
      const data = await response.json() as { error?: string; message?: string };
      if (!response.ok) throw new Error(data.error || "Unable to update order");
      window.location.reload();
    } catch (error) { setNotice(error instanceof Error ? error.message : "Something went wrong"); }
    finally { setBusyId(""); }
  }
  if (!orders.length) return <div className="rounded-3xl border border-dashed border-[#e8ddd2] p-8 text-center text-sm text-[#777487]">No orders yet. Your orders will appear here after a customer checks out.</div>;
  return <div className="space-y-3">{notice && <p role="alert" className="text-sm text-red-700">{notice}</p>}{orders.map(order=>{
    const own = order.subOrders[0];
    return <article key={order._id} className="rounded-2xl border border-[#f0e9e1] bg-white p-5"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-black">{order.orderNumber}</p><p className="mt-1 text-xs text-[#777487]">{new Date(order.createdAt).toLocaleString()} · {order.paymentStatus}</p></div><span className="rounded-full bg-[#fff0e3] px-3 py-1 text-xs font-bold">{own.status}</span></div><ul className="mt-4 space-y-1 text-sm text-[#625d70]">{own.items.map((item,i)=><li key={`${item.titleSnapshot}-${i}`}>{item.quantity} × {item.titleSnapshot}</li>)}</ul><div className="mt-4 flex flex-wrap items-center justify-between gap-3"><strong>৳{own.subtotal.toLocaleString("en-BD")}</strong>{order.paymentMethod !== "cod" && order.paymentStatus !== "paid" ? <span className="text-xs font-bold text-[#a45b2d]">Awaiting payment</span> : <div className="flex gap-2">{own.status === "pending" && (order.paymentMethod === "cod" || order.paymentStatus === "paid") && <button disabled={busyId===order._id} onClick={()=>update(order._id,"confirmed")} className="rounded-full bg-[#b8edc7] px-4 py-2 text-xs font-bold">Confirm</button>}{own.status === "confirmed" && <button disabled={busyId===order._id} onClick={()=>update(order._id,"processing")} className="rounded-full bg-[#e8ddff] px-4 py-2 text-xs font-bold">Start processing</button>}{own.status === "processing" && <button disabled={busyId===order._id} onClick={()=>update(order._id,"shipped")} className="rounded-full bg-[#dceaff] px-4 py-2 text-xs font-bold">Mark shipped</button>}{own.status === "shipped" && <button disabled={busyId===order._id} onClick={()=>update(order._id,"delivered")} className="rounded-full bg-[#b8edc7] px-4 py-2 text-xs font-bold">Mark delivered</button>}</div>}</div></article>;
  })}</div>;
}

export function VendorProductActions({ productId, price, stock }: { productId: string; price: number; stock: number }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function update() {
    const nextPrice = window.prompt("Update selling price (৳):", String(price));
    if (nextPrice === null) return;
    const nextStock = window.prompt("Update stock quantity:", String(stock));
    if (nextStock === null) return;
    const parsedPrice = Number(nextPrice), parsedStock = Number(nextStock);
    if (!Number.isFinite(parsedPrice) || parsedPrice <= 0 || !Number.isInteger(parsedStock) || parsedStock < 0) { setMessage("Enter a valid price and whole-number stock."); return; }
    setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/vendor/products", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ productId, price: parsedPrice, stock: parsedStock }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Unable to update product");
      window.location.reload();
    } catch (error) { setMessage(error instanceof Error ? error.message : "Something went wrong"); }
    finally { setBusy(false); }
  }
  async function archive() {
    if (!window.confirm("Archive this listing? It will no longer be available for sale.")) return;
    setBusy(true); setMessage("");
    try {
      const response = await fetch(`/api/vendor/products?productId=${encodeURIComponent(productId)}`, { method: "DELETE" });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Unable to archive product");
      window.location.reload();
    } catch (error) { setMessage(error instanceof Error ? error.message : "Something went wrong"); }
    finally { setBusy(false); }
  }
  return <div className="flex flex-col items-end gap-1"><div className="flex gap-2"><button disabled={busy} onClick={update} className="rounded-full border border-[#eee5dc] px-3 py-1.5 text-xs font-bold">Edit</button><button disabled={busy} onClick={archive} className="rounded-full bg-[#ffe0dc] px-3 py-1.5 text-xs font-bold">Archive</button></div>{message && <span role="status" className="max-w-36 text-right text-[11px] text-red-700">{message}</span>}</div>;
}
