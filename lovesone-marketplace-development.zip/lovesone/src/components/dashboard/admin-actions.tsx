"use client";

import { useState } from "react";

type ActionResult = { message?: string; error?: string };

export function ReviewAction({ productId, medicine }: { productId: string; medicine: boolean }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function review(decision: "approve" | "reject") {
    setBusy(true); setMessage("");
    try {
      const approvalReference = medicine && decision === "approve" ? window.prompt("Enter verified medicine compliance reference:") : undefined;
      if (medicine && decision === "approve" && !approvalReference) { setBusy(false); return; }
      const response = await fetch(`/api/admin/products/${productId}/review`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ decision, approvalReference }) });
      const data = await response.json() as ActionResult;
      if (!response.ok) throw new Error(data.error || "Could not update listing");
      setMessage(data.message || "Updated"); window.location.reload();
    } catch (error) { setMessage(error instanceof Error ? error.message : "Something went wrong"); }
    finally { setBusy(false); }
  }
  return <div className="flex flex-wrap items-center gap-2"><button disabled={busy} onClick={() => review("approve")} className="rounded-full bg-[#b8edc7] px-4 py-2 text-xs font-bold disabled:opacity-50">Approve</button><button disabled={busy} onClick={() => review("reject")} className="rounded-full bg-[#ffe0dc] px-4 py-2 text-xs font-bold disabled:opacity-50">Reject</button>{message && <span role="status" className="text-xs text-[#a45b2d]">{message}</span>}</div>;
}

export function VendorApprovalAction({ vendorId }: { vendorId: string }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function approve() {
    setBusy(true); setMessage("");
    try {
      const response = await fetch(`/api/admin/vendors/${vendorId}/approve`, { method: "POST" });
      const data = await response.json() as ActionResult;
      if (!response.ok) throw new Error(data.error || "Could not approve vendor");
      setMessage(data.message || "Approved"); window.location.reload();
    } catch (error) { setMessage(error instanceof Error ? error.message : "Something went wrong"); }
    finally { setBusy(false); }
  }
  return <div className="flex items-center gap-3"><button onClick={approve} disabled={busy} className="rounded-full bg-[#b8edc7] px-4 py-2 text-xs font-bold disabled:opacity-50">{busy ? "Approving…" : "Approve seller"}</button>{message && <span role="status" className="text-xs">{message}</span>}</div>;
}
