import Link from "next/link";
import { Heart, Search, Store, UserRound } from "lucide-react";
import { CartHeaderLink } from "@/components/storefront/cart-provider";
import { auth } from "../../auth";

const links = [
  ["Shop all", "/shop"],
  ["Cats", "/shop?pet=cats"],
  ["Dogs", "/shop?pet=dogs"],
  ["Small pets", "/shop?pet=small-pets"],
  ["Health & care", "/shop?category=health"]
];

export async function SiteHeader() {
  const session = await auth();
  const role = session?.user?.role;
  const dashboardHref = role === "admin" || role === "super-admin" ? "/admin" : role === "vendor" ? "/vendor/dashboard" : "/account";
  return <>
    <div className="bg-[#27233a] px-4 py-2 text-center text-xs font-semibold text-white">A little treat for your first order — welcome to the pack! 🐾</div>
    <header className="sticky top-0 z-30 border-b border-[#f0e9e1] bg-[#fff8ef]/95 backdrop-blur"><div className="container flex min-h-[76px] items-center justify-between gap-5">
      <Link href="/" className="flex items-center gap-2 text-[25px] font-black tracking-[-.06em]"><span className="grid size-10 place-items-center rounded-2xl bg-[#ff914d] text-xl">🐾</span>LOVES<span className="text-[#ff914d]">ONE</span></Link>
      <nav className="hidden items-center gap-6 text-sm font-bold lg:flex">{links.map(([label, href]) => <Link key={label} href={href} className="transition hover:text-[#e87532]">{label}</Link>)}</nav>
      <div className="flex items-center gap-2"><Link href="/shop" aria-label="Search products" className="grid size-10 place-items-center rounded-full border border-[#f0e9e1] bg-white"><Search size={18}/></Link><button aria-label="Wishlist" className="hidden size-10 place-items-center rounded-full border border-[#f0e9e1] bg-white sm:grid"><Heart size={18}/></button><CartHeaderLink />
        {session?.user ? <Link href={dashboardHref} className="flex items-center gap-2 rounded-full border border-[#f0e9e1] bg-white px-4 py-2 text-sm font-bold"><UserRound size={16}/><span className="hidden sm:inline">Dashboard</span></Link> : <Link href="/login" className="rounded-full border border-[#f0e9e1] bg-white px-4 py-2 text-sm font-bold">Sign in</Link>}
        <Link href="/vendor/register" className="hidden items-center gap-2 rounded-full border border-[#f0e9e1] bg-white px-4 py-2 text-sm font-bold md:flex"><Store size={16}/> Sell with us</Link>
      </div>
    </div></header>
  </>;
}
